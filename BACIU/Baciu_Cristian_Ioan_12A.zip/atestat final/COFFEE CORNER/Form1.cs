﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;



namespace WindowsFormsApplication8
{

    public partial class Form1 : Form
    {


        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'baciuDataSet1.Produse' table. You can move, or remove it, as needed.
            this.produseTableAdapter1.Fill(this.baciuDataSet1.Produse);
            // TODO: This line of code loads data into the 'baciuDataSet1.Orase' table. You can move, or remove it, as needed.
            this.oraseTableAdapter1.Fill(this.baciuDataSet1.Orase);
            // TODO: This line of code loads data into the 'baciuDataSet1.Furnizori' table. You can move, or remove it, as needed.
            this.furnizoriTableAdapter1.Fill(this.baciuDataSet1.Furnizori);
            // TODO: This line of code loads data into the 'baciuDataSet1.Caracteristici' table. You can move, or remove it, as needed.
            this.caracteristiciTableAdapter1.Fill(this.baciuDataSet1.Caracteristici);
            // TODO: This line of code loads data into the 'baciuDataSet1.Angajati' table. You can move, or remove it, as needed.
            this.angajatiTableAdapter1.Fill(this.baciuDataSet1.Angajati);
            // TODO: This line of code loads data into the 'baciuDataSet1.Angajati' table. You can move, or remove it, as needed.
           
            // TODO: This line of code loads data into the 'baciuDataSet.Furnizori' table. You can move, or remove it, as needed.
            this.furnizoriTableAdapter1.Fill(this.baciuDataSet1.Furnizori);
            // TODO: This line of code loads data into the 'baciuDataSet1.Angajatii' table. You can move, or remove it, as needed.



            
            oraseTableAdapter1.Oras(baciuDataSet1.Orase);
            DataTable dt = baciuDataSet1.Orase;
            baciuDataSet1.EnforceConstraints = false;
            for (int i = 0; i < dt.Rows.Count; i++)
            { comboBox1.Items.Add(dt.Rows[i]["Denumire"]); comboBox2.Items.Add(dt.Rows[i]["Denumire"]); }



        }











        private void button5_Click(object sender, EventArgs e)
        {
            //baciuDataSet.FurnizoriRow newfurnizorirow;
            //newfurnizorirow = baciuDataSet.Furnizori.NewFurnizoriRow();

            //newfurnizorirow.Denumire = comboBox3.SelectedItem.ToString();

            //newfurnizorirow.Data =dateTimePicker1.Value  ; 
            //newfurnizorirow.Nume = comboBox2.SelectedItem.ToString();
            //this.baciuDataSet.Furnizori.Rows.Add(newfurnizorirow);
            //this.furnizoriTableAdapter.Update(this.baciuDataSet.Furnizori);
            //this.furnizoriTableAdapter.Fill(this.baciuDataSet.Furnizori);




        }



        private void comboBox2_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            
       
            comboBox3.Items.Clear();
            if (comboBox2.SelectedItem != null)
            {
                string value = comboBox2.SelectedItem.ToString();
                string valueoras = "Cluj-Napoca                   ";
                int iii = value.CompareTo(valueoras);

                if (iii == 0)
                {

                    produseTableAdapter1.prod1(baciuDataSet1.Produse);
                    DataTable dtt = baciuDataSet1.Produse;
                    for (int i = 0; i < dtt.Rows.Count; i++)
                        comboBox3.Items.Add(dtt.Rows[i]["Denumire"]);
                }
                else
                {

                    produseTableAdapter1.prod2(baciuDataSet1.Produse);
                    DataTable dttt = baciuDataSet1.Produse;
                    for (int i = 0; i < dttt.Rows.Count; i++)
                        comboBox3.Items.Add(dttt.Rows[i]["Denumire"]);

                }
            
        }
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem != null)
            {
                richTextBox2.Clear();

                furnizoriTableAdapter1.incasari(baciuDataSet1.Furnizori, comboBox1.SelectedItem.ToString());
                DataTable dt = baciuDataSet1.Furnizori;
                for (int i = 0; i < dt.Rows.Count; i++)
                    richTextBox2.Text += dt.Rows[i]["Nume"].ToString() + "\n" + "INCASARI=" + dt.Rows[i]["Expr1"].ToString() + "\n";

            }
            else MessageBox.Show("NU AI SELECTAT ORASUL");
        }
        private void button3_Click_1(object sender, EventArgs e)
        {
            
       
            richTextBox2.Clear();
            oraseTableAdapter1.MaxMinSalariuOras(baciuDataSet1.Orase, comboBox1.SelectedItem.ToString());
            DataTable dt = baciuDataSet1.Orase;
            for (int i = 0; i < dt.Rows.Count; i++)
                richTextBox2.Text += dt.Rows[i]["Denumire"].ToString() + "\n" + "MAX=" + dt.Rows[i]["MAX"].ToString() + "\n" + "MIN=" + dt.Rows[i]["MIN"].ToString() + "\n";
        

        }
        SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\Cristian\Documents\baciu.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True");
       
        private void button10_Click_1(object sender, EventArgs e)
        {



            if (comboBox2.SelectedItem != null && comboBox3.SelectedItem!=null )
            {
                con.Open();

                SqlCommand cmd = con.CreateCommand();

                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "INSERT INTO Furnizori (Nume, Denumire, Cantitate, Data) VALUES (@Nume,@Denumire,@Cantitate,@Data)";


                cmd.Parameters.AddWithValue("@Nume", comboBox2.SelectedItem.ToString());
                cmd.Parameters.AddWithValue("@Denumire", comboBox3.SelectedItem.ToString());

                cmd.Parameters.AddWithValue("@Cantitate", int.Parse(textBox1.Text));
                cmd.Parameters.AddWithValue("@Data", dateTimePicker1.Value);


                cmd.ExecuteNonQuery();
                this.furnizoriTableAdapter1.Fill(this.baciuDataSet1.Furnizori);
                this.furnizoriTableAdapter1.Update(this.baciuDataSet1.Furnizori);




                con.Close();
            }
            else MessageBox.Show("NU AI SELECTAT TOATE DATELE");

        
        }

        private void button6_Click_1(object sender, EventArgs e)
        {
            if (comboBox2.SelectedItem != null && comboBox3.SelectedItem != null)
            {
                textBox3.Clear();
                produseTableAdapter1.pretul(baciuDataSet1.Produse, comboBox3.SelectedItem.ToString());
                DataTable dt = baciuDataSet1.Produse;
                double var = double.Parse(dt.Rows[0]["Pret"].ToString());
                int varvar = int.Parse(textBox1.Text.Trim());

                textBox3.Text += var * varvar;

                MessageBox.Show(String.Format("PUTETI RIDICA COMANDA IN VALOARE DE {0} LEI! VA MULTUMIM:)", textBox3.Text));
            }
            else MessageBox.Show("NU ATI SELECTAT TOATE DATELE");


        
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
         
            richTextBox3.Clear();

            furnizoriTableAdapter1.cant(baciuDataSet1.Furnizori);
            DataTable dt = baciuDataSet1.Furnizori;
            for (int i = 0; i < dt.Rows.Count; i++)
                richTextBox3.Text += dt.Rows[i]["Nume"].ToString() + "\n" + "Cantitate Medie " + dt.Rows[i]["Expr1"].ToString() + "\n";
        
        }

        private void button8_Click_1(object sender, EventArgs e)
        {
         
            richTextBox3.Clear();
            furnizoriTableAdapter1.cantvanduta(baciuDataSet1.Furnizori);
            DataTable dt = baciuDataSet1.Furnizori;
            for (int i = 0; i < dt.Rows.Count; i++)
                richTextBox3.Text += dt.Rows[i]["Expr1"] + " la " + dt.Rows[i]["Nume"] + "\n";
        

        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem != null)
            {
                richTextBox2.Clear();
                oraseTableAdapter1.MediePretProduse(baciuDataSet1.Orase, comboBox1.SelectedItem.ToString());
                DataTable dt = baciuDataSet1.Orase;
                for (int i = 0; i < dt.Rows.Count; i++)
                    richTextBox2.Text += dt.Rows[i]["Denumire"].ToString() + "\n" + "PRET MEDIU=" + dt.Rows[i]["Medie"].ToString();
            }
            else MessageBox.Show("SELECTEAZA ORAS");

        
        }

        private void button7_Click(object sender, EventArgs e)
        {
            richTextBox3.Clear();
            produseTableAdapter1.ProduseRisc200(baciuDataSet1.Produse);
            DataTable dt = baciuDataSet1.Produse;
            for (int i = 0; i < dt.Rows.Count; i++)
                richTextBox3.Text += dt.Rows[i]["ID"].ToString() + " " + dt.Rows[i]["Denumire"] + "\n" + "SUMA(kcal,lipide,carbohidrati,proteine)=" + dt.Rows[i]["Expr1"].ToString() + "\n\n";
     
        }

        private void button9_Click_1(object sender, EventArgs e)
        {
            MessageBox.Show("TE MAI ASTEPTAM!");
            this.Close();
            
        

        }

        private void sTATISTICAToolStripMenuItem_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage2;
        }

        private void cOMANDAToolStripMenuItem_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage1;
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void wELCOMEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage4;

            
        }

        private void sTATISTICAToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage3;
        }

        private void tabPage4_Click(object sender, EventArgs e)
        {

        }


       



















    }
}
